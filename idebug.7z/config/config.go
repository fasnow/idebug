package config

const Version = "v1.0.2"
