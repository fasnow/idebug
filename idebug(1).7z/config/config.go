package config

import (
	"idebug/plugin"
)

var Info plugin.ClientInfo
var Proxy string
